import requests
from django.core.management.base import BaseCommand
from TP1_Inforoute.models import Dataset
from django.utils.dateparse import parse_datetime

CKAN_BASE_URL = "https://www.donneesquebec.ca/recherche/api/3/action"

class Command(BaseCommand):
    help = "Moissonne tous les jeux de données depuis donneesquebec.ca"

    def handle(self, *args, **options):
        self.stdout.write("Début du moissonnage CKAN...")

        start = 0
        rows = 100  # Nombre de datasets par requête (max accepté par CKAN)
        total_fetched = 0

        while True:
            search_url = f"{CKAN_BASE_URL}/package_search?start={start}&rows={rows}"
            response = requests.get(search_url)
            if not response.ok:
                self.stdout.write(self.style.ERROR("Erreur lors de la récupération des datasets"))
                break

            results = response.json().get("result", {})
            datasets_list = results.get("results", [])

            if not datasets_list:
                break  # plus de datasets

            for data in datasets_list:
                dataset, created = Dataset.objects.update_or_create(
                    ckan_id=data.get("id"),
                    defaults={
                        "name": data.get("name"),
                        "title": data.get("title"),
                        "notes": data.get("notes"),
                        "author": data.get("author"),
                        "author_email": data.get("author_email"),
                        "organization_id": (data.get("organization") or {}).get("id"),
                        "organization_title": (data.get("organization") or {}).get("title"),
                        "license_id": data.get("license_id"),
                        "license_title": data.get("license_title"),
                        "license_url": data.get("license_url"),
                        "metadata_created": parse_datetime(data.get("metadata_created")),
                        "metadata_modified": parse_datetime(data.get("metadata_modified")),
                        "state": data.get("state"),
                        "private": data.get("private", False),
                        "tags": [t["display_name"] for t in data.get("tags", [])],
                        "groups": [g["display_name"] for g in data.get("groups", [])],
                    },
                )
                action = "Créé" if created else "Mis à jour"
                self.stdout.write(f"✔ {action} : {dataset.title}")

            total_fetched += len(datasets_list)
            start += rows
            self.stdout.write(f"Total moissonnés : {total_fetched}")

        self.stdout.write(self.style.SUCCESS("✅ Moissonnage terminé avec succès !"))